-- Guildie: whisper-phrase guild invites + custom welcome messages for WoW: Forever
local ADDON_NAME, ns = ...

ns.DEFAULTS = {
    -- Auto-invite
    enabled        = true,
    phrase         = "guild inv",
    matchAnywhere  = false,   -- false = whisper must equal the phrase; true = phrase anywhere in the whisper
    confirm        = false,   -- true = popup you click before each invite
    cooldown       = 15,      -- seconds before the same player can trigger again
    replyEnabled   = true,
    replyText      = "Invite sent! Welcome to {guild}.",
    -- Welcome message
    welcomeEnabled = true,
    welcomeText    = "Everyone welcome {name} to {guild}!",
    welcomeWhisperText = "Welcome to {guild}, {name}! Glad to have you. Say hi in guild chat and shout if you need anything.",
    welcomeOnlyMine = true,   -- only welcome players Guildie invited (stops double welcomes between officers)
    welcomeDelay   = 3,
    debug          = false,   -- /guildie debug: print why each whisper was or wasn't acted on
    -- Armory: what you share with guildmates
    shareGear        = true,
    shareTalents     = true,
    shareProfessions = true,
    shareGold        = false,  -- opt-in
    -- Minimap button
    minimapShow    = true,
    minimapAngle   = 200,
    -- Anniversaries
    birthdayEnabled    = true,
    birthdayText       = "|cff33ff99Guildie:|r happy birthday, {name}!",
    anniversaryEnabled = true,
    anniversaryText    = "|cff33ff99Guildie:|r everyone congratulate {name} on {years} year(s) in {guild}!",
    -- Recruit welcome kit: up to three whispers sent to new recruits
    kitEnabled     = false,
    kit1           = "",
    kit2           = "",
    kit3           = "",
    -- Armory views and sharing
    groupAlts      = true,    -- show alts under their main
    shareRecipes   = true,
    -- linkAlts is left unset until the player answers the one-time question
    -- Gamer word counter (shown in the Armory). Only ever a number.
    gamerCounter   = true,
    gamerWords     = 0,
    -- Stats
    stats          = { invited = 0, welcomed = 0 },
}

ns.log = {}
ns.invitedByMe = {}
local lastSeen = {}
local db

local GetMeta = (C_AddOns and C_AddOns.GetAddOnMetadata) or GetAddOnMetadata
ns.VERSION = (GetMeta and GetMeta(ADDON_NAME, "Version")) or "dev"

-- Modern API first, legacy fallback
local Invite   = (C_GuildInfo and C_GuildInfo.Invite) or GuildInvite
local SendChat = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage

function ns.RefreshUI() end -- replaced by UI.lua

---------------------------------------------------------------------------
-- Helpers
---------------------------------------------------------------------------
function ns.Print(msg)
    print("|cff33ff99Guildie:|r " .. msg)
end

-- Every debug line is also kept (last 250) in the saved settings, so a problem can be diagnosed
-- afterwards from /guildie report or the saved-variables file, without having to catch it live.
function ns.Debug(msg)
    local d = ns.db
    if not d then return end
    d.trace = d.trace or {}
    d.trace[#d.trace + 1] = date("%m/%d %H:%M:%S ") .. tostring(msg)
    if #d.trace > 250 then table.remove(d.trace, 1) end
    if d.debug then
        print("|cffff9933Guildie debug:|r " .. tostring(msg))
    end
end

-- Hooks: feature modules (recruits, alts, kit ...) listen for things Core notices.
local hooks = {}
function ns.AddHook(name, fn)
    hooks[name] = hooks[name] or {}
    table.insert(hooks[name], fn)
end

local reported = {}
function ns.ReportError(what, err)     -- say it once, instead of failing silently
    if ns.Issue then ns.Issue("lua", what, err) end
    if reported[what] then return end
    reported[what] = true
    ns.Print(("|cffff5555Something went wrong in %s:|r %s"):format(what, tostring(err)))
end

function ns.Fire(name, ...)
    for _, fn in ipairs(hooks[name] or {}) do
        local ok, err = pcall(fn, ...)
        if not ok then ns.ReportError("Guildie (" .. name .. ")", err) end
    end
end

function ns.Safe(what, fn)
    return function(...)
        local ok, err = pcall(fn, ...)
        if not ok then ns.ReportError(what, err) end
    end
end

-- Forever runs the retail Secret Values system; secrets can't be compared or matched.
local function IsSecret(v)
    return issecretvalue ~= nil and issecretvalue(v)
end

local function Trim(s)
    return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", ""))
end
ns.Trim = Trim

-- Lowercase, strip color codes / links / raid-icon tokens, collapse whitespace
local function Normalize(s)
    s = tostring(s or "")
    s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    s = s:gsub("|H.-|h(.-)|h", "%1"):gsub("|T.-|t", ""):gsub("{.-}", "")
    s = s:gsub("%s+", " ")
    return Trim(s):lower()
end

local function ShortName(name)
    if Ambiguate then return Ambiguate(name, "short") end
    return name:match("^[^%-]+") or name
end

local function Key(name)
    return ShortName(name):lower()
end

-- Whether this client has shown that guild invites need a real click. Remembered per client
-- build, so a Forever patch that loosens the rule gets re-tested automatically.
local function ClientBuild() return tostring((select(2, GetBuildInfo()))) end
function ns.InviteNeedsClick()
    -- Always. The game reports a blocked action every time addon code calls the invite function,
    -- on every build, so the only invite that works is the popup's secure button (/ginvite).
    return true
end

-- Same for chat: once the game has blocked an automatic chat message, remember that for this
-- client build and go straight to the click popup, instead of trying (and being blocked) again.
-- Learned per channel: Forever blocks add-on guild chat but lets whispers through, so one blocked
-- channel must not push the others behind a click popup.
ns.chatNeedsClickBy = {}
function ns.ChatNeedsClick(chan)
    chan = chan or "GUILD"
    if ns.chatNeedsClickBy[chan] then return true end
    local by = ns.db and ns.db.chatNeedsClickBy
    return type(by) == "table" and by[chan] ~= nil and by[chan] == ClientBuild()
end
function ns.SetChatNeedsClick(chan)
    chan = chan or "GUILD"
    ns.chatNeedsClickBy[chan] = true
    if ns.db then
        if type(ns.db.chatNeedsClickBy) ~= "table" then ns.db.chatNeedsClickBy = {} end
        ns.db.chatNeedsClickBy[chan] = ClientBuild()
    end
end

function ns.Fill(template, name)
    local guild = GetGuildInfo("player") or "the guild"
    local short = ShortName(name)
    local out = Trim(template)
        :gsub("{name}", function() return short end)
        :gsub("{guild}", function() return guild end)
    return (out:sub(1, 255))
end

function ns.Log(name, action)
    table.insert(ns.log, 1, { t = date("%H:%M"), name = ShortName(name), action = action })
    if #ns.log > 50 then table.remove(ns.log) end
    ns.RefreshUI()
end

---------------------------------------------------------------------------
-- Chat sending, queued around chat lockdown (encounters, etc.)
---------------------------------------------------------------------------
local queue, flushPending = {}, false

local function ChatLocked()
    if C_ChatInfo and C_ChatInfo.InChatMessagingLockdown then
        local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
        if ok and locked then return true end
    end
    return false
end

-- Forever flags SendChatMessage as restricted (it may need a real click). We can't always
-- tell from the call itself, so we watch for our own message to come back (guild echo /
-- whisper inform). If it doesn't show up, the message didn't go out: fall back to a click.
local echoWatch = {}

function ns.SendNow(text, chan, target)            -- call only from a click handler
    ns.lastChatAt = GetTime()
    ns.lastChatChan = chan
    ns.lastChatWasClick = true
    return pcall(SendChat, text, chan, nil, target)
end

local function WatchEcho(m)
    local w = { text = m.text, chan = m.chan, onFail = m.onFail, done = false }
    echoWatch[#echoWatch + 1] = w
    m.watch = w
    C_Timer.After(4, function()
        for i, x in ipairs(echoWatch) do if x == w then table.remove(echoWatch, i) break end end
        if not w.done then
            ns.SetChatNeedsClick(w.chan)
            ns.Debug("  no echo for " .. w.chan .. " message: the game didn't send it")
            if w.onFail then w.onFail(w.text) end
        end
    end)
end

-- The game told us a chat message was blocked: fail everything still waiting for its echo now,
-- instead of after the timeout.
local function FailWatches()
    for i = #echoWatch, 1, -1 do
        local w = echoWatch[i]
        if not w.done then
            w.done = true
            if w.onFail then w.onFail(w.text) end
        end
    end
end

function ns.OnChatEcho(chan, text)
    for _, w in ipairs(echoWatch) do
        -- a secret echo can't be compared; count it for the oldest message on that channel
        if not w.done and w.chan == chan and (IsSecret(text) or w.text == text) then
            w.done = true
            return
        end
    end
end

local function Flush()
    flushPending = false
    while #queue > 0 and not ChatLocked() do
        local m = table.remove(queue, 1)
        if m.onFail then WatchEcho(m) end            -- watch first: the echo can arrive immediately
        ns.lastChatAt = GetTime()
        ns.lastChatChan = m.chan
        ns.lastChatWasClick = false
        local ok = pcall(SendChat, m.text, m.chan, nil, m.target)
        if not ok then
            ns.SetChatNeedsClick(m.chan)
            if m.watch then m.watch.done = true end  -- fail now, not again after the timeout
            if m.onFail then m.onFail(m.text) end
        end
    end
    if #queue > 0 and not flushPending then
        flushPending = true
        C_Timer.After(5, Flush)
    end
end

function ns.Say(text, chan, target, onFail)
    if Trim(text) == "" then return end
    ns.Debug(("  sending %s: %s"):format(chan, text))
    queue[#queue + 1] = { text = text, chan = chan, target = target, onFail = onFail }
    Flush()
end

---------------------------------------------------------------------------
-- Inviting
---------------------------------------------------------------------------
-- fromClick: called from a button the player clicked, so restricted calls are allowed.
-- The reply whisper is sent only after the invite looks like it went through (see below).
function ns.DoInvite(name, fromClick, viaMacro)
    if ns.IsSelfTest(name) then ns.SelfTestInvite(name, fromClick) return end
    ns.blockedAt = nil
    ns.blockedNamed = nil
    ns.lastInviteAt = GetTime()
    local okInv, errInv = true, nil
    if viaMacro then
        -- the popup button itself ran "/ginvite Name" as a secure macro; nothing to call here
        ns.Debug("invite for " .. tostring(name) .. ": sent by the popup's secure button (/ginvite)")
    else
        okInv, errInv = pcall(Invite, name)
        ns.Debug(("invite call for %s: fromClick=%s ok=%s%s"):format(tostring(name), tostring(fromClick and true or false),
            tostring(okInv), okInv and "" or (" err=" .. tostring(errInv))))
    end
    if not okInv then
        ns.Debug("  Invite call failed: " .. tostring(errInv))
        ns.blockedAt = GetTime() ns.blockedNamed = true
    end
    local sentAt = GetTime()
    ns.invitedByMe[Key(name)] = sentAt
    ns.inviteFailed[Key(name)] = nil
    ns.StartRosterPoll()
    -- The game gives no "invite sent" reply, so wait a few seconds for any sign of trouble
    -- (a blocked call, an error message, a "declined / already in a guild" reply) before
    -- counting the invite or telling the player it was sent.
    C_Timer.After(0.5, function()
        -- Only a block that names the invite counts as the invite failing. The game often reports
        -- UNKNOWN() for whatever else Guildie did in the same moment, and that is not proof.
        if ns.blockedAt and ns.blockedNamed then
            if fromClick then
                ns.Log(name, "|cffff5555Invite blocked by the game|r")
                ns.Print(("The game didn't send the invite to %s. Check /guildie debug on and try again."):format(name))
                ns.QueueInvite(name)
            else
                -- don't drop the recruit: ask for the click the game wants
                ns.QueueInvite(name)
            end
            return
        end
        C_Timer.After(3, function()
            local k = Key(name)
            local err = ns.lastUIError and ns.lastUIError.at >= sentAt and ns.lastUIError.text
            if ns.inviteFailed[k] and ns.inviteFailed[k] >= sentAt then
                ns.Debug("  invite to " .. name .. " failed: server reply")
                return                       -- CheckInviteResult already logged why
            end
            if err then
                ns.Debug("  invite to " .. name .. " failed: " .. tostring(err))
                ns.Log(name, "|cffff5555Invite failed: " .. tostring(err) .. "|r")
                ns.Print(("The invite to %s did not go through: %s"):format(name, tostring(err)))
                return
            end
            db.stats.invited = db.stats.invited + 1
            ns.Log(name, "|cff55ff55Invited|r")
            ns.Debug("  invite to " .. name .. ": no error from the game, counting it as sent"
                .. ((ns.blockedAt and not ns.blockedNamed) and " (an unnamed blocked action was reported at the same time; ignored)" or ""))
            if fromClick then ns.Print("Invited " .. name .. ".") end
            if db.replyEnabled then ns.SendReply(name) end
        end)
    end)
end

function ns.SendReply(name)
    local text = ns.Fill(db.replyText, name)
    local function needClick()
        ns.Log(name, "|cffffaa00Reply whisper waiting for your click|r")
        if ns.ShowSendToast then ns.ShowSendToast("Whisper " .. ShortName(name) .. "?", text, "WHISPER", name) end
    end
    if ns.ChatNeedsClick("WHISPER") then needClick() return end
    ns.Say(text, "WHISPER", name, needClick)
end

---------------------------------------------------------------------------
-- /guildie selftest: runs two fake whispers through the real pipeline (phrase match, queue,
-- popup, your click) without inviting anyone, then reports each step.
---------------------------------------------------------------------------
local selfTest
function ns.IsSelfTest(name)
    return selfTest ~= nil and type(name) == "string" and name:find("^Selftest ") ~= nil
end

local function STReport()
    if not selfTest or selfTest.reported then return end
    selfTest.reported = true
    local function line(ok, text) ns.Print((ok and "|cff55ff55PASS|r " or "|cffff5555FAIL|r ") .. text) end
    local st = selfTest
    ns.Print("|cffd9a441Self-test results|r (nobody was invited)")
    line(st.settings, "settings: auto-invite on, phrase set, in a guild with invite rights")
    line(st.matched, "whispers containing the phrase were recognised")
    if ns.InviteNeedsClick() or db.confirm then
        line(st.queued == 2, ("both whispers queued for the popup (%d of 2)"):format(st.queued))
        line(st.popup, "the invite popup appeared at the top of the screen")
        line(st.clicked > 0, st.clicked > 0 and ("your click reached the invite step for %d player(s) in one click%s"):format(st.clicked,
            (st.clicked < 2 and ns.OnePerClick()) and " (this game build allows one invite per click, so the second stays queued)" or "")
            or "no click reached the invite step - the popup was never clicked within a minute")
    else
        line(st.auto == 2, ("automatic invites reached the invite step for %d of 2 whispers"):format(st.auto))
    end
    ns.Print(("Still only provable live: whether the game accepts the real invite and chat. Learned so far -> invite needs a click: %s, chat needs a click: %s.")
        :format(tostring(ns.InviteNeedsClick()), tostring(ns.ChatNeedsClick("GUILD"))))
    -- clean up the fakes
    local keep = {}
    for _, p in ipairs(ns.pendingInvites) do if not ns.IsSelfTest(p.name) then keep[#keep + 1] = p end end
    ns.pendingInvites = keep
    if ns.RefreshInviteToast then ns.RefreshInviteToast() end
    selfTest = nil
end

function ns.SelfTestInvite(name, fromClick)
    if fromClick then selfTest.clicked = selfTest.clicked + 1 else selfTest.auto = selfTest.auto + 1 end
    ns.Debug(("selftest: invite step reached for %s (fromClick=%s) - dry run, GuildInvite not called"):format(name, tostring(fromClick and true or false)))
    if fromClick then
        C_Timer.After(0.5, STReport)
    elseif selfTest.auto >= 2 then
        C_Timer.After(0.5, STReport)
    end
end

function ns.SelfTest()
    if selfTest then ns.Print("A self-test is already running.") return end
    selfTest = { settings = false, matched = false, queued = 0, popup = false, clicked = 0, auto = 0 }
    local phrase = Trim(tostring(db.phrase or "")):lower()
    selfTest.settings = db.enabled and phrase ~= "" and IsInGuild() and CanGuildInvite() and true or false
    if not selfTest.settings then
        STReport()
        return
    end
    ns.Print("Self-test: sending two fake whispers (\"Selftest One\", \"Selftest Two\") through Guildie...")
    for _, who in ipairs({ "Selftest One", "Selftest Two" }) do
        lastSeen[Key(who)] = nil
        ns.InjectWhisper((tostring(db.phrase):match("[^,;]+") or ""):gsub("^%s+", ""), who)
    end
    for _, p in ipairs(ns.pendingInvites) do if ns.IsSelfTest(p.name) then selfTest.queued = selfTest.queued + 1 end end
    selfTest.matched = (selfTest.queued == 2) or (selfTest.auto == 2)
    C_Timer.After(0.3, function()
        local t = _G.GuildieToast
        selfTest.popup = (t and t:IsShown()) and true or false
        if ns.InviteNeedsClick() or db.confirm then
            ns.Print("Click |cff33ff99Send|r on the popup (or press your bound key) to finish the test.")
        end
    end)
    C_Timer.After(60, STReport)
end

---------------------------------------------------------------------------
-- Invites waiting for your click. Everyone who asks joins one queue and one popup lists them
-- all, so a second request never replaces the first. One click invites everyone waiting; if
-- the game turns out to allow only one invite per click, Guildie notices from the server's
-- replies, puts the rest back in the queue, and goes one per click on this game build.
---------------------------------------------------------------------------
ns.pendingInvites = {}
ns.inviteFailed = {}            -- [key] = time the server refused an invite we sent
ns.inviteAnswered = {}          -- [key] = time the server answered an invite we sent
local INVITE_WAIT = 1800        -- a request is dropped after 30 minutes without a click

function ns.QueueInvite(name)
    local k = Key(name)
    ns.Debug("QueueInvite " .. tostring(name) .. " (waiting now: " .. #ns.pendingInvites .. ")")
    for _, p in ipairs(ns.pendingInvites) do if p.key == k then return end end
    ns.pendingInvites[#ns.pendingInvites + 1] = { name = name, key = k, at = GetTime() }
    ns.Log(name, "|cffffaa00Waiting for you to send the invite|r")
    ns.AlertInvite()
    -- refresh the popup when this request would expire, so a stale name never lingers
    C_Timer.After(INVITE_WAIT + 1, function()
        ns.PendingInvites()
        if ns.RefreshInviteToast then ns.RefreshInviteToast() end
    end)
end

-- A request arrived: a sound and a flash, then the chat bar is filled with "/ginvite Name".
-- You press Enter. Guildie does nothing else, so the game sees an ordinary typed command.
function ns.AlertInvite()
    local list = ns.PendingInvites()
    if #list == 0 then return end
    pcall(function() PlaySound((SOUNDKIT and SOUNDKIT.TELL_MESSAGE) or 3081) end)
    if FlashClientIcon then pcall(FlashClientIcon) end
    if InCombatLockdown and InCombatLockdown() then
        ns.Print(("%s wants a guild invite (in combat: waiting)."):format(ShortName(list[1].name)))
        return
    end
    if _G.ACTIVE_CHAT_EDIT_BOX then
        ns.Print(("%s wants a guild invite: /ginvite %s"):format(ShortName(list[1].name), list[1].name))
        return
    end
    ns.PrefillInvite()
end

function ns.PendingInvites()
    local now, keep = GetTime(), {}
    for _, p in ipairs(ns.pendingInvites) do
        if now - p.at < INVITE_WAIT then
            keep[#keep + 1] = p
        else
            ns.Log(p.name, "|cff888888Invite request expired (no click within 30 minutes)|r")
        end
    end
    ns.pendingInvites = keep
    return keep
end

function ns.OnePerClick()
    return db.inviteOnePerClick ~= nil and db.inviteOnePerClick == ClientBuild()
end

-- Runs from the popup's button: a real click, or the key from /guildie bind.
-- The people the next click will invite (the popup's secure button uses the same list).
function ns.InviteBatch()
    local list = ns.PendingInvites()
    if #list == 0 then return list end
    return ns.OnePerClick() and { list[1] } or list
end

-- Click on the popup: put "/ginvite Name" in the chat box. Pressing Enter runs it as a normal
-- typed command, which the game allows; Guildie notices it was sent (see the hooks below).
ns.awaiting = nil
function ns.PrefillInvite()
    local list = ns.PendingInvites()
    local p = list[1]
    if not p then return 0 end
    local aw = { key = p.key, name = p.name, at = GetTime() }
    ns.awaiting = aw
    local text = "/ginvite " .. p.name
    ns.Debug("popup click: putting \"" .. text .. "\" in the chat box; waiting for Enter")
    local okOpen = ns.db and ns.db.prefillChatBox and ChatFrame_OpenChat and pcall(ChatFrame_OpenChat, text, DEFAULT_CHAT_FRAME)
    if okOpen then
        ns.Print(("Press |cff33ff99Enter|r to invite %s."):format(ShortName(p.name)))
    else
        ns.Print(("%s wants a guild invite. Type: |cff33ff99%s|r"):format(ShortName(p.name), text))
    end
    C_Timer.After(45, function()
        if ns.awaiting == aw then
            ns.awaiting = nil
            ns.Debug("no Enter pressed for " .. p.name .. " within 45s")
            if #ns.PendingInvites() > 0 and ns.ShowInviteToast then ns.ShowInviteToast() end
        end
    end)
    return 1
end

-- Guild chat from an add-on is blocked on Forever even from a click, but a line you send with Enter
-- is allowed. So the popup's click puts the line in the chat box and you press Enter to post it.
ns.awaitingChat = nil
function ns.PrefillChat(text, cmd, onSent)
    local aw = { text = text, cmd = cmd, onSent = onSent, at = GetTime() }
    ns.awaitingChat = aw
    ns.Debug("popup click: putting " .. cmd .. " line in the chat box; waiting for Enter")
    local okOpen = ns.db and ns.db.prefillChatBox and ChatFrame_OpenChat and pcall(ChatFrame_OpenChat, cmd .. " " .. text, DEFAULT_CHAT_FRAME)
    if okOpen then
        ns.Print("Press |cff33ff99Enter|r to post it.")
    else
        ns.Print(("Type this, then press Enter: |cff33ff99%s %s|r"):format(cmd, text))
    end
    C_Timer.After(60, function() if ns.awaitingChat == aw then ns.awaitingChat = nil end end)
end

-- Called with the text of a chat line the moment Enter is pressed.
function ns.OnChatLine(text)
    local ac = ns.awaitingChat
    if ac and type(text) == "string" then
        local t = Trim(text)
        if t == Trim(ac.text) or t:sub(1, #ac.cmd + 1) == ac.cmd .. " " then
            ns.awaitingChat = nil
            ns.Debug("Enter pressed: welcome line posted by you")
            if ac.onSent then pcall(ac.onSent) end
            return
        end
    end
    local aw = ns.awaiting
    if not aw or type(text) ~= "string" then return end
    local who = text:match("^/ginvite%s+(.-)%s*$") or text:match("^/guildinvite%s+(.-)%s*$")
    if not who or Key(who) ~= aw.key then return end
    ns.awaiting = nil
    local keep = {}
    for _, p in ipairs(ns.pendingInvites) do if p.key ~= aw.key then keep[#keep + 1] = p end end
    ns.pendingInvites = keep
    ns.Debug("Enter pressed: " .. text .. " (sent by you, not by the addon)")
    ns.DoInvite(aw.name, true, true)
    if #ns.PendingInvites() > 0 and ns.ShowInviteToast then ns.ShowInviteToast() end
end

function ns.HookChatBoxes()
    -- off by default: Guildie stays out of the chat box so the game treats /ginvite as a command you typed
    if not (ns.db and ns.db.hookChat) then return end
    if ns.chatHooked then return end
    ns.chatHooked = true
    for i = 1, (NUM_CHAT_WINDOWS or 10) do
        local eb = _G["ChatFrame" .. i .. "EditBox"]
        if eb and eb.HookScript then
            eb:HookScript("OnTextChanged", function(self)
                local t = self:GetText()
                if t and t ~= "" then ns.lastEditText = t end
            end)
            eb:HookScript("OnEnterPressed", function() local t = ns.lastEditText ns.lastEditText = nil if t then ns.OnChatLine(t) end end)
        end
    end
end

function ns.SendQueuedInvites(viaMacro)
    local list = ns.PendingInvites()
    if #list == 0 then return 0 end
    local batch = ns.InviteBatch()
    ns.Debug(("popup click: %d waiting, sending %d invite(s) (one per click: %s)"):format(#list, #batch, tostring(ns.OnePerClick())))
    local inBatch, rest = {}, {}
    for _, p in ipairs(batch) do inBatch[p.key] = true end
    for _, p in ipairs(list) do if not inBatch[p.key] then rest[#rest + 1] = p end end
    ns.pendingInvites = rest
    local sentAt = GetTime()
    for _, p in ipairs(batch) do ns.DoInvite(p.name, true, viaMacro) end
    if #batch > 1 then
        -- which invites did the server actually get?
        C_Timer.After(3, function()
            local answered, missed = 0, {}
            for _, p in ipairs(batch) do
                local t = ns.inviteAnswered[p.key]
                if t and t >= sentAt then answered = answered + 1 else missed[#missed + 1] = p end
            end
            if answered > 0 and #missed > 0 then
                db.inviteOnePerClick = ClientBuild()
                ns.Print(("The game sent %d of %d invites from that click, so Guildie will invite one person per click from now on. The other %d are back in the queue.")
                    :format(answered, #batch, #missed))
                for i = #missed, 1, -1 do
                    local p = missed[i]
                    p.at = GetTime()
                    table.insert(ns.pendingInvites, 1, p)
                    ns.Log(p.name, "|cffffaa00Back in the queue (one invite per click)|r")
                end
                if ns.ShowInviteToast then ns.ShowInviteToast() end
            end
        end)
    end
    return #batch
end

function ns.SkipQueuedInvites()
    for _, p in ipairs(ns.pendingInvites) do ns.Log(p.name, "|cff888888Invite skipped|r") end
    ns.pendingInvites = {}
end

-- During chat lockdown a whisper's text and sender arrive secret. Its lineID never is,
-- so remember it and read the line again once lockdown ends.
local lockedLines, lockPolling = {}, false
local OnWhisper

local function PollLockedLines()
    lockPolling = false
    if #lockedLines == 0 then return end
    if not ChatLocked() and C_ChatInfo and C_ChatInfo.GetChatLineText then
        local now = GetTime()
        for i = #lockedLines, 1, -1 do
            local e = lockedLines[i]
            local okT, text = pcall(C_ChatInfo.GetChatLineText, e.lineID)
            local okS, who = pcall(C_ChatInfo.GetChatLineSenderName, e.lineID)
            if okT and okS and text and who and not IsSecret(text) and not IsSecret(who) then
                table.remove(lockedLines, i)
                ns.Debug("recovered a whisper from chat lockdown (line " .. e.lineID .. ")")
                OnWhisper(text, who)
            elseif now - e.t > 900 then
                table.remove(lockedLines, i)                -- give up after 15 minutes
            end
        end
    end
    if #lockedLines > 0 then
        lockPolling = true
        C_Timer.After(2, PollLockedLines)
    end
end

OnWhisper = function(msg, sender, lineID)
    if not db.enabled then ns.Debug("  -> ignored: auto-invite is turned off (/guildie on)") return end
    if IsSecret(msg) or IsSecret(sender) then
        if not ns.warnedSecret then
            ns.warnedSecret = true
            ns.Print("A whisper arrived but the game hides its text from add-ons right now (combat, an encounter or chat lockdown). Guildie will read it again as soon as that ends.")
        end
        if lineID and not IsSecret(lineID) then
            lockedLines[#lockedLines + 1] = { lineID = lineID, t = GetTime() }
            ns.Debug("whisper arrived during chat lockdown; will read it when lockdown ends")
            if not lockPolling then lockPolling = true C_Timer.After(2, PollLockedLines) end
        else
            ns.Debug("whisper skipped: unreadable (chat lockdown) and no line ID")
        end
        return
    end

    local text = Normalize(msg)
    ns.Debug(("whisper from %s: raw=%q normalized=%q phrase=%q anywhere=%s"):format(
        tostring(sender), tostring(msg), text, tostring(db.phrase), tostring(db.matchAnywhere)))
    -- The phrase box may hold several phrases separated by commas. Spaces, dashes and punctuation
    -- are ignored, and "guild"/"g" and "inv"/"invite" count as the same word, so "g invite",
    -- "ginvite", "g-inv", "guild inv" and "Guild Invite!" all match one another.
    local function Canon(x)
        x = Normalize(x):gsub("[^%w]", "")
        x = x:gsub("^guild", "g"):gsub("invite$", "inv"):gsub("invite", "inv")
        return x
    end
    local ctext, any = Canon(text), false
    local hit
    for part in tostring(db.phrase or ""):gmatch("[^,;]+") do
        local cp = Canon(part)
        if cp ~= "" then
            any = true
            if db.matchAnywhere then
                -- search the whisper's words, not the squashed text, so "login" can't hit "g inv"
                local padded = " " .. text:gsub("[^%w]+", " ") .. " "
                local np = Normalize(part):gsub("[^%w]+", " ")
                hit = padded:find(" " .. np .. " ", 1, true) ~= nil or ctext:find(cp, 1, true) ~= nil and #cp >= 4
            else
                hit = (ctext == cp)
            end
            if hit then break end
        end
    end
    if not any then return end
    if not hit then
        ns.Debug("  -> no match")
        return
    end

    if not IsInGuild() or not CanGuildInvite() then
        ns.Print(ShortName(sender) .. " sent your invite phrase, but you can't invite (no guild, or your rank lacks invite rights).")
        ns.Log(sender, "|cffffaa00No invite rights|r")
        return
    end

    local now, k = GetTime(), Key(sender)
    local cd = tonumber(db.cooldown) or 60
    if lastSeen[k] and now - lastSeen[k] < cd then
        local left = math.ceil(cd - (now - lastSeen[k]))
        ns.Debug(("  -> matched, but on cooldown (%ds left)"):format(left))
        ns.Log(sender, ("|cff888888Ignored: cooldown %ds|r"):format(left))
        return
    end
    lastSeen[k] = now

    if db.confirm or ns.InviteNeedsClick() then
        ns.Debug(db.confirm and "  -> matched, showing confirm popup"
            or "  -> matched; this client needs a click to invite, showing popup")
        ns.QueueInvite(sender)
    else
        ns.Debug("  -> matched, inviting")
        ns.DoInvite(sender)
    end
end

function ns.InjectWhisper(msg, who) return OnWhisper(msg, who) end

-- Server replies to our invites, so the log shows what actually happened
local function BuildPattern(fmt)
    local p = fmt:gsub("([%(%)%.%%%+%-%*%?%[%]%^%$])", "%%%1")
    p = p:gsub("%%%%s", "(.+)")
    return "^" .. p .. "$"
end

local INVITE_RESULTS = {}
local function AddResult(fmt, label, clearCooldown)
    if type(fmt) == "string" and fmt:find("%%s") then
        INVITE_RESULTS[#INVITE_RESULTS + 1] = { pattern = BuildPattern(fmt), label = label, clear = clearCooldown }
    end
end
AddResult(ERR_GUILD_INVITE_S,              "|cff55ff55Invite delivered|r", false)
AddResult(ERR_GUILD_DECLINE_S,             "|cffff5555Declined invite|r", true)
AddResult(ERR_GUILD_DECLINE_AUTO_S,        "|cffff5555Auto-declined (blocks guild invites)|r", true)
AddResult(ERR_ALREADY_IN_GUILD_S,          "|cffffaa00Already in a guild|r", true)
AddResult(ERR_ALREADY_INVITED_TO_GUILD_S,  "|cffffaa00Already has a pending invite|r", true)
AddResult(ERR_GUILD_PLAYER_NOT_FOUND_S,    "|cffff5555Player not found|r", true)

local function CheckInviteResult(msg)
    for _, r in ipairs(INVITE_RESULTS) do
        local who = msg:match(r.pattern)
        if who then
            who = (who:gsub("|H.-|h%[?(.-)%]?|h", "%1"))
            local k = Key(who)
            -- the invite you sent yourself: take it out of the waiting list and do the usual bookkeeping
            if not ns.invitedByMe[k] then
                for i, p in ipairs(ns.pendingInvites) do
                    if p.key == k then
                        table.remove(ns.pendingInvites, i)
                        if ns.awaiting and ns.awaiting.key == k then ns.awaiting = nil end
                        pcall(ns.DoInvite, p.name, true, true)
                        if #ns.pendingInvites > 0 then C_Timer.After(1, ns.AlertInvite) end
                        break
                    end
                end
            end
            if ns.invitedByMe[k] then
                ns.inviteAnswered[k] = GetTime()
                if r.clear then ns.inviteFailed[k] = GetTime() end
                ns.Debug("  server: " .. msg)
                ns.Log(who, r.label)
                if r.clear then
                    lastSeen[k] = nil       -- let them try again right away
                    ns.invitedByMe[k] = nil
                end
            end
            return true
        end
    end
    return false
end

---------------------------------------------------------------------------
-- Welcoming
---------------------------------------------------------------------------
local JOIN_PATTERN = BuildPattern(ERR_GUILD_JOIN_S or "%s has joined the guild.")
local LEAVE_PATTERN = BuildPattern(ERR_GUILD_LEAVE_S or "%s has left the guild.")
local KICK_PATTERN = BuildPattern(ERR_GUILD_REMOVE_SS or "%s has been kicked out of the guild by %s.")
local welcomed = {}      -- key -> time, so chat line + roster can't both welcome someone
local joinSeen = {}      -- key -> time, so the join hook fires once per join

local function Welcome(who, source)
    local k = Key(who)
    if welcomed[k] and GetTime() - welcomed[k] < 300 then return end

    local mine = ns.invitedByMe[k] and (GetTime() - ns.invitedByMe[k] < 1800)
    ns.Debug(("join detected via %s: %s (invited by Guildie: %s)"):format(source, who, tostring(mine and true or false)))
    if not joinSeen[k] or GetTime() - joinSeen[k] > 300 then
        joinSeen[k] = GetTime()
        ns.Fire("join", who, source, mine and true or false)
    end

    if not db.welcomeEnabled or Trim(db.welcomeText) == "" then
        ns.Log(who, "|cff888888Joined (welcome message is off)|r")
        return
    end
    if db.welcomeOnlyMine and not mine then
        ns.Log(who, "|cff888888Joined (not a Guildie invite, no welcome)|r")
        return
    end
    welcomed[k] = GetTime()
    ns.invitedByMe[k] = nil
    ns.Log(who, "|cffaaaaaaJoined the guild|r")
    ns.Fire("welcome", who)

    C_Timer.After(tonumber(db.welcomeDelay) or 3, function()
        local text = ns.Fill(db.welcomeText, who)
        local popup
        local function needClick()
            if db.welcomeWhisper ~= false and not ns.ChatNeedsClick("WHISPER") and not ns.welcomeWhispered then
                -- guild chat is blocked for add-ons, whispers are not: welcome them privately
                ns.welcomeWhispered = who
                local wtext = ns.Fill(db.welcomeWhisperText or "Welcome to {guild}, {name}!", who)
                ns.Say(wtext, "WHISPER", who, function() ns.welcomeWhispered = nil popup() end)
                C_Timer.After(4.5, function()
                    if ns.welcomeWhispered == who then
                        ns.welcomeWhispered = nil
                        db.stats.welcomed = db.stats.welcomed + 1
                        ns.Log(who, "|cff66ccffJoined + welcomed (whisper)|r")
                    end
                end)
                return
            end
            popup()
        end
        popup = function()
            ns.Log(who, "|cffffaa00Welcome waiting for your click|r")
            if not ns.toldNeedsClick then
                ns.toldNeedsClick = true
                ns.Print("The game didn't post the welcome by itself, so it's waiting for your click on the popup at the top of your screen.")
            end
            if ns.ShowSendToast then
                ns.ShowSendToast("Welcome " .. ShortName(who) .. " to the guild?", text, "GUILD", nil, function()
                    db.stats.welcomed = db.stats.welcomed + 1
                    ns.Log(who, "|cff66ccffJoined + welcomed|r")
                end)
            end
        end
        if ns.ChatNeedsClick("GUILD") then needClick() return end   -- already learned: go straight to the popup
        ns.Say(text, "GUILD", nil, needClick)
        C_Timer.After(4.5, function()
            if not ns.ChatNeedsClick("GUILD") then
                db.stats.welcomed = db.stats.welcomed + 1
                ns.Log(who, "|cff66ccffJoined + welcomed|r")
            end
        end)
    end)
end

-- /guildie testwelcome: finds out whether this client lets Guildie post to guild chat by itself.
-- It runs on a timer, not inside the slash command (a typed command counts as a keypress and
-- would always be allowed), so it behaves exactly like a real join.
function ns.TestWelcome()
    if not IsInGuild() then ns.Print("You're not in a guild.") return end
    ns.Print("Welcome test: one test line will post in guild chat in 2 seconds.")
    C_Timer.After(2, function()
        local text = "[Guildie test] Checking that welcome messages can post. Ignore me!"
        ns.chatNeedsClickBy.GUILD = nil
        if ns.db and type(ns.db.chatNeedsClickBy) == "table" then ns.db.chatNeedsClickBy.GUILD = nil end
        local failed = false
        ns.Say(text, "GUILD", nil, function()
            failed = true
            ns.Print("|cffffaa00Result: the game did NOT let Guildie post by itself.|r Welcomes will wait for one click on a popup at the top of your screen.")
            if ns.ShowSendToast then ns.ShowSendToast("Welcome test", text, "GUILD") end
        end)
        C_Timer.After(5, function()
            if not failed then
                ns.Print("|cff55ff55Result: the test line posted by itself.|r Automatic welcomes work on this client.")
            end
        end)
    end)
end

-- Someone left: forget that we welcomed them, so a later rejoin is welcomed and recorded again.
local function Forget(name)
    local k = Key(name)
    joinSeen[k] = nil
    welcomed[k] = nil
end

local function OnSystem(msg)
    if IsSecret(msg) then
        ns.Debug("system message skipped: secret value")
        return
    end
    if next(ns.invitedByMe) then ns.Debug("system: " .. msg) end
    if CheckInviteResult(msg) then return end
    local who = msg:match(JOIN_PATTERN)
    if who then
        Welcome((who:gsub("|H.-|h%[?(.-)%]?|h", "%1")), "chat")
        return
    end
    local gone = msg:match(LEAVE_PATTERN)
    if gone then
        gone = gone:gsub("|H.-|h%[?(.-)%]?|h", "%1")
        Forget(gone)
        ns.Fire("leave", gone, false)
        return
    end
    local kicked = msg:match(KICK_PATTERN)
    if kicked then
        kicked = kicked:gsub("|H.-|h%[?(.-)%]?|h", "%1")
        Forget(kicked)
        ns.Fire("leave", kicked, true)
    end
end

-- Roster diff: catches joins even if the join chat line is worded differently
local roster                -- set of member keys from the last full roster read
local RequestRoster = (C_GuildInfo and C_GuildInfo.GuildRoster) or GuildRoster

local function ReadRoster()
    if not IsInGuild() then return nil end
    local n = GetNumGuildMembers()
    if not n or n == 0 then return nil end
    local set = {}
    for i = 1, n do
        local name = GetGuildRosterInfo(i)
        if name and not IsSecret(name) then set[Key(name)] = name end
    end
    return set
end

function ns.RosterSet() return ReadRoster() or {} end

local function OnRoster()
    local current = ReadRoster()
    if not current then return end
    if roster then
        local new = {}
        for k, name in pairs(current) do
            if not roster[k] then new[#new + 1] = name end
        end
        -- A real join adds one or two names. A big jump means the roster was still loading in
        -- pieces, and those are not new members.
        if #new > 0 and #new <= 3 then
            for _, name in ipairs(new) do Welcome(name, "roster") end
        elseif #new > 3 then
            ns.Debug(("roster grew by %d at once: treating it as a reload, not joins"):format(#new))
        end
    end
    roster = current
    ns.Fire("roster", current)
end

-- After inviting, poll the roster for a few minutes so a join is noticed quickly
local polling = false
local function PollRoster(remaining)
    if remaining <= 0 or not next(ns.invitedByMe) then polling = false return end
    if RequestRoster then pcall(RequestRoster) end
    C_Timer.After(10, function() PollRoster(remaining - 1) end)
end
function ns.StartRosterPoll()
    if polling then return end
    polling = true
    PollRoster(18)   -- ~3 minutes
end

---------------------------------------------------------------------------
-- Saved settings (mirrored per-character: some Forever beta builds
-- write account SavedVariables but don't reload them)
---------------------------------------------------------------------------
local function ApplyDefaults(t)
    for k, v in pairs(ns.DEFAULTS) do
        if t[k] == nil then
            t[k] = (type(v) == "table") and CopyTable(v) or v
        end
    end
end

local function LoadDB()
    local src
    if type(GuildieDB) == "table" and next(GuildieDB) then
        src = GuildieDB
    elseif type(GuildieCharDB) == "table" and next(GuildieCharDB) then
        src = GuildieCharDB
    else
        src = {}
    end
    ApplyDefaults(src)
    -- 1.4.x turned "Ask me before each invite" on by itself; give the player their setting back
    if src.confirmAuto then
        src.confirm = false
        src.confirmAuto = nil
        src.inviteNeedsClick = ClientBuild()
    end
    GuildieDB, GuildieCharDB = src, src
    db, ns.db = src, src
end

function ns.ResetDefaults()
    local stats = db.stats
    wipe(db)
    ApplyDefaults(db)
    db.stats = stats
    ns.RefreshUI()
    ns.Print("Settings reset to defaults.")
end

---------------------------------------------------------------------------
-- Events
---------------------------------------------------------------------------
local f = CreateFrame("Frame")
-- An event this client doesn't have RAISES and would abort the file, so guard each one
ns.eventStatus = {}
for _, ev in ipairs({ "ADDON_LOADED", "PLAYER_LOGIN", "CHAT_MSG_WHISPER", "CHAT_MSG_SYSTEM",
    "ADDON_ACTION_BLOCKED", "ADDON_ACTION_FORBIDDEN", "PLAYER_GUILD_UPDATE", "GUILD_ROSTER_UPDATE",
    "CHAT_MSG_GUILD", "CHAT_MSG_WHISPER_INFORM", "UI_ERROR_MESSAGE" }) do
    local ok = pcall(f.RegisterEvent, f, ev)
    ns.eventStatus[ev] = ok and true or false
end

f:SetScript("OnEvent", function(_, event, ...)
    if event == "ADDON_LOADED" then
        if ... == ADDON_NAME then
            LoadDB()
            f:UnregisterEvent("ADDON_LOADED")
        end
        return
    end
    if not db then return end

    if event == "PLAYER_LOGIN" then
        local bad = {}
        for ev, ok in pairs(ns.eventStatus) do if not ok then bad[#bad + 1] = ev end end
        ns.Debug(("login: version %s build %s; events not registered: %s; enabled=%s phrase=%q"):format(
            tostring(ns.VERSION), tostring(ClientBuild()), #bad > 0 and table.concat(bad, ",") or "none",
            tostring(db.enabled), tostring(db.phrase)))
        if ns.RegisterSettings then ns.RegisterSettings() end
        pcall(ns.HookChatBoxes)
        if RequestRoster then pcall(RequestRoster) end
    elseif event == "CHAT_MSG_WHISPER" then
        local msg, sender = ...
        ns.whispersSeen = (ns.whispersSeen or 0) + 1
        if IsSecret(msg) or IsSecret(sender) then
            ns.Debug("event: whisper #" .. ns.whispersSeen .. " arrived with secret text/sender (chat lockdown)")
        else
            ns.Debug(("event: whisper #%d from %s"):format(ns.whispersSeen, tostring(sender)))
        end
        OnWhisper(msg, sender, (select(11, ...)))
    elseif event == "CHAT_MSG_GUILD" then
        local text, _, _, _, _, _, _, _, _, _, _, guid = ...
        local me = UnitGUID("player")
        if IsSecret(guid) or (guid and me and not IsSecret(me) and guid == me) then ns.OnChatEcho("GUILD", text) end
    elseif event == "CHAT_MSG_WHISPER_INFORM" then
        ns.OnChatEcho("WHISPER", (...))
    elseif event == "CHAT_MSG_SYSTEM" then
        OnSystem((...))
    elseif event == "ADDON_ACTION_BLOCKED" or event == "ADDON_ACTION_FORBIDDEN" then
        local addon, func = ...
        if addon ~= ADDON_NAME then return end
        func = tostring(func or "")
        -- always say which function the game blocked (once every few seconds), so a problem like this
        -- can be pinned down without turning debug on first
        if not ns.lastBlockedPrint or GetTime() - ns.lastBlockedPrint > 5 then
            ns.lastBlockedPrint = GetTime()
            ns.Print(("|cffff8844The game blocked:|r %s (%s). Copy this line if it keeps happening."):format(func, tostring(event)))
        end
        ns.Debug(("blocked action reported: %s (%s), %.1fs after our last invite, %.1fs after our last chat")
            :format(func, tostring(event), GetTime() - (ns.lastInviteAt or -100), GetTime() - (ns.lastChatAt or -100)))
        -- The game often reports the blocked function as UNKNOWN(). Go by its name when we get
        -- one, otherwise by whatever we tried a moment ago.
        local now = GetTime()
        local sinceInvite = now - (ns.lastInviteAt or -100)
        local sinceChat = now - (ns.lastChatAt or -100)
        local kind
        if func:find("Invite") then kind = "invite"
        elseif func:find("Chat") then kind = "chat"
        elseif sinceInvite < 1.5 or sinceChat < 1.5 then
            kind = (sinceInvite <= sinceChat) and "invite" or "chat"
        end
        if kind == "invite" then
            ns.blockedAt = GetTime()
            ns.blockedNamed = func:find("Invite") ~= nil
            if not ns.InviteNeedsClick() then
                db.inviteNeedsClick = ClientBuild()
                ns.Print("Forever requires a click to send guild invites, so Guildie will show a popup for each one. Your settings are unchanged.")
            end
        elseif kind == "chat" then
            if ns.lastChatWasClick and sinceChat < 1.5 then
                ns.Print("The game blocked that message even though it came from your click. Forever may not let addons post this kind of chat at all.")
            else
                ns.SetChatNeedsClick(ns.lastChatChan)
                ns.Debug("the game blocked an automatic chat message; from now on welcomes wait for your click")
                FailWatches()
            end
        else
            ns.Debug("the game blocked " .. func .. " (" .. event .. ")")
        end
        ns.RefreshUI()
    elseif event == "UI_ERROR_MESSAGE" then
        local _, text = ...
        if type(text) == "string" and not IsSecret(text) and next(ns.invitedByMe) then
            ns.lastUIError = { text = text, at = GetTime() }
            ns.Debug("ui error: " .. text)
        end
    elseif event == "GUILD_ROSTER_UPDATE" then
        OnRoster()
        ns.RefreshUI()
    else
        ns.RefreshUI() -- guild status changed
    end
end)

-- /guildie report: what Guildie has learned about this client plus the last debug lines
function ns.Report(n)
    local P = ns.Print
    local bad = {}
    for ev, ok in pairs(ns.eventStatus or {}) do if not ok then bad[#bad + 1] = ev end end
    P(("report: version %s, build %s, in guild: %s, can invite: %s"):format(tostring(ns.VERSION),
        tostring(ClientBuild()), tostring(IsInGuild()), tostring(IsInGuild() and CanGuildInvite())))
    P(("enabled=%s phrase=%q matchAnywhere=%s confirm=%s cooldown=%s"):format(tostring(db.enabled), tostring(db.phrase),
        tostring(db.matchAnywhere), tostring(db.confirm), tostring(db.cooldown)))
    P(("learned: invites need a click=%s, chat needs a click=%s, one invite per click=%s; whispers seen this session: %d; waiting invites: %d"):format(
        tostring(ns.InviteNeedsClick()), tostring(ns.ChatNeedsClick()), tostring(ns.OnePerClick()),
        ns.whispersSeen or 0, #(ns.pendingInvites or {})))
    P("events not registered: " .. (#bad > 0 and table.concat(bad, ", ") or "none"))
    local t = db.trace or {}
    P(("last %d of %d debug lines:"):format(math.min(n, #t), #t))
    for i = math.max(1, #t - n + 1), #t do print("  " .. t[i]) end
end

---------------------------------------------------------------------------
-- Slash commands + addon compartment
---------------------------------------------------------------------------
SLASH_GUILDIE1 = "/guildie"
SLASH_GUILDIE2 = "/gie"
SlashCmdList.GUILDIE = function(input)
    if not db then return end
    local cmd, rest = Trim(input):match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()

    if cmd == "" or cmd == "config" or cmd == "options" then
        ns.ToggleUI()
    elseif cmd == "on" or cmd == "off" then
        db.enabled = (cmd == "on")
        ns.Print("Auto-invite " .. (db.enabled and "|cff55ff55enabled|r" or "|cffff5555disabled|r"))
    elseif cmd == "phrase" and rest ~= "" then
        db.phrase = rest
        ns.Print("Invite phrase set to: " .. rest)
    elseif cmd == "welcome" and rest ~= "" then
        db.welcomeText = rest
        ns.Print("Welcome message set to: " .. rest)
    elseif cmd == "armory" or cmd == "a" then
        ns.ToggleArmory()
    elseif cmd == "minimap" then
        db.minimapShow = (db.minimapShow == false)
        ns.UpdateMinimapButton()
        ns.Print("Minimap button " .. (db.minimapShow and "shown." or "hidden. Type /guildie minimap to bring it back."))
    elseif cmd == "synctest" then
        ns.Armory.SyncTest()
    elseif cmd == "testwelcome" then
        ns.TestWelcome()
    elseif cmd == "anniversaries" or cmd == "dates" then
        if ns.OpenArmoryTab then ns.OpenArmoryTab("anniversaries") end
    elseif cmd == "joined" then
        if ns.Dates then ns.Dates.SlashJoined(rest) end
    elseif cmd == "birthday" or cmd == "bday" then
        if ns.Dates then ns.Dates.SlashBirthday(rest) end
    elseif cmd == "timezone" or cmd == "tz" then
        if rest:lower():match("^clear") then
            if ns.Timezones then ns.Timezones.Clear() end
        else
            local off, label = rest:match("^(%S+)%s*(.*)$")
            if ns.Timezones then ns.Timezones.Set(off, label) end
        end
    elseif cmd == "zone" or cmd == "where" then
        if ns.Zone then ns.Zone.Command(rest) end
    elseif cmd == "schedule" then
        if ns.OpenArmoryTab then ns.OpenArmoryTab("schedule") end
    elseif cmd == "bind" then
        local key, opt = rest:match("^(%S+)%s*(%S*)")
        ns.BindSend(key, (opt or ""):lower() == "force")
    elseif cmd == "unbind" then
        ns.UnbindSend()
    elseif cmd == "crafters" or cmd == "recruits" or cmd == "loot" then
        if ns.OpenArmoryTab then ns.OpenArmoryTab(cmd) end
    elseif cmd == "alts" then
        if ns.Alts then ns.Alts.Command(rest) end
    elseif cmd == "main" then
        if ns.Alts then ns.Alts.SetMain(rest) end
    elseif cmd == "recipes" then
        if ns.Recipes and rest:lower() == "probe" then ns.Recipes.Probe()
        else ns.Print("/guildie recipes probe - check what the game reports for an open profession window") end
    elseif cmd == "words" then
        local G = ns.GamerWords
        if rest:lower() == "reset" then
            G.Reset()
            ns.Print("Gamer word counter reset to 0.")
        else
            ns.Print(("Gamer words counted: |cffffd100%d|r (this session: %d)"):format(G.Total(), G.session))
        end
    elseif cmd == "debug" then
        db.debug = not db.debug
        ns.Print("Debug " .. (db.debug and "|cff55ff55on|r: every whisper will be explained in chat." or "|cffff5555off|r"))
    elseif cmd == "selftest" then
        ns.SelfTest()
    elseif cmd == "report" then
        ns.Report(tonumber(rest) or 20)
    elseif cmd == "preview" then
        ns.Print("Preview: " .. ns.Fill(db.welcomeText, UnitName("player")))
    else
        ns.Print("/guildie - open settings")
        ns.Print("/guildie armory - open the guild armory")
        ns.Print("/guildie synctest - check whether guild sync works on this client")
        ns.Print("/guildie minimap - show or hide the minimap button")
        ns.Print("/guildie testwelcome - check whether welcomes can post to guild chat by themselves")
        ns.Print("/guildie bind <key> - press a key to send the welcome popup (/guildie unbind to remove)")
        ns.Print("/guildie words [reset] - show or reset the gamer word counter")
        ns.Print("/guildie crafters | recruits | loot | schedule | anniversaries - open that Armory tab")
        ns.Print("/guildie zone - who's in your zone and who has quests there (share on|off, alerts on|off)")
        ns.Print("/guildie joined [date] | birthday [month/day] - set your guild join date and birthday (shared with the guild)")
        ns.Print("/guildie timezone <offset> [label] - share your time zone for raid scheduling (/guildie timezone clear to remove)")
        ns.Print("/guildie alts [link|unlink] - see and share which characters are yours; /guildie main <name> picks your main")
        ns.Print("/guildie recipes probe - check that the game shares recipes")
        ns.Print("/guildie on | off - toggle auto-invite")
        ns.Print("/guildie phrase <text> - set the whisper phrase")
        ns.Print("/guildie welcome <text> - set the welcome message ({name}, {guild})")
        ns.Print("/guildie preview - preview the welcome message")
        ns.Print("/guildie debug - explain every whisper in chat (troubleshooting)")
        ns.Print("/guildie report [lines] - what Guildie has learned about this game plus the latest debug lines")
    end
    ns.RefreshUI()
end

function Guildie_OnAddonCompartmentClick()
    ns.ToggleUI()
end
