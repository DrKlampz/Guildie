# Guildie

## [v1.15.0](https://github.com/DrKlampz/Guildie/tree/v1.15.0) (2026-11-17)
[Full Changelog](https://github.com/DrKlampz/Guildie/compare/v1.14.4...v1.15.0) [Previous Releases](https://github.com/DrKlampz/Guildie/releases)

- v1.15.0: share gamer word counts per hour so the total covers offline time  
    Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>  
    Claude-Session: https://claude.ai/code/session\_016tjqgsa2XbatSMrUya2RRK  
